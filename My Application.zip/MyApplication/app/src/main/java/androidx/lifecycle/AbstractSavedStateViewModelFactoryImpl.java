package androidx.lifecycle;

public class AbstractSavedStateViewModelFactoryImpl extends AbstractSavedStateViewModelFactory {
}
