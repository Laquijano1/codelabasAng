package com.example.myapplication.repository

import com.example.myapplication.data.model.MovieList

interface MovieRepository {
    suspend fun getUpcomingMovies():MovieList
    suspend fun getTopRatedMovies():MovieList
    suspend fun getPopularMovies():MovieList
}