package com.example.myapplication.core

sealed class Resource<out T> {

    class Loading<out T> : Resource<T>()
    data class Success<out T>(val data: T) //me devuelve el dato pedido
    data class Failure<out T>(val exception: Exception) : Resource<Nothing>()

}