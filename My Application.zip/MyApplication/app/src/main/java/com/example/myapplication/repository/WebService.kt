package com.example.myapplication.repository

import com.example.myapplication.application.AppConstants
import com.example.myapplication.data.model.MovieList
import com.google.gson.GsonBuilder
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

import retrofit2.http.GET
import retrofit2.http.Query

interface WebService {
    @GET(value = "movie/upcoming")
    suspend fun getUpcomingMovies(@Query(value = "api_key") apiKey: String): MovieList

    @GET(value = "movie/top_rated")
    suspend fun getTopRatedMovies(@Query(value = "api_key") apiKey: String): MovieList

    @GET(value = "movie/popular")
    suspend fun getPopularMovies(@Query(value = "api_key") apiKey: String): MovieList
}

object RetrofitClient {
    val webservice by lazy {
        return@lazy Retrofit.Builder()
            .baseUrl(AppConstants.BASE_URL)
            //Si muestra error crear dependencia 'com.squareup.retrofit2:converter-gson:2.9.0'
            .addConverterFactory(GsonConverterFactory.create(GsonBuilder().create()))
            .build().create(WebService::class.java)

    }
}