package com.example.myapplication.application

object AppConstants {
    //API
    const val BASE_URL = "https://api.themoviedb.org/3/"
    const val API_KEY = "413b5432b8765968b11b19eec4f8ab74"
}