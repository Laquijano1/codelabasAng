package com.example.myapplication.UI.DETALLES

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import com.example.myapplication.R
import com.example.myapplication.databinding.FragmentDetallesBinding


class DETALLES3 : Fragment(R.layout.fragment_detalles) {
    private lateinit var binding: FragmentDetallesBinding
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding = FragmentDetallesBinding.bind(view)
    }
}

