package com.example.livecicle

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

abstract class WordRoomDataBase {
    // Annotates class to be a Room Database with a table (entity) of the Word class
    @Database(entities=arrayOf(word.Word::class), version=1, exportSchema=false)
    abstract class WordRoomDatabase : RoomDatabase() {

        abstract fun wordDao(): wordDAO

        private class WordDatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {

            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch {
                        val wordDAO=database.wordDao()

                        // Delete all content here.
                        wordDAO.deleteAll()

                        // Add sample words.
                        var word=word.Word("Hello")
                        wordDAO.insert(word)
                        word=com.example.livecicle.word.Word("World!")
                        wordDAO.insert(word)

                        // TODO: Add your own words!
                        word=com.example.livecicle.word.Word("TODO!")
                        wordDAO.insert(word)
                    }
                }
            }
        }

        companion object {
            @Volatile
            private var INSTANCE: WordRoomDatabase?=null

            fun getDatabase(
                context: Context,
                scope: CoroutineScope
            ): WordRoomDatabase {
                // if the INSTANCE is not null, then return it,
                // if it is, then create the database
                return INSTANCE ?: synchronized(this) {
                    val instance=Room.databaseBuilder(
                        context.applicationContext,
                        WordRoomDatabase::class.java,
                        "word_database"
                    )
                        .addCallback(WordDatabaseCallback(scope))
                        .build()
                    INSTANCE=instance
                    // return instance
                    instance
                }
            }
        }
    }
}