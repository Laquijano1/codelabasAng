package com.example.livecicle

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class WordsApplication: Application() {
    val applicationScope = CoroutineScope(SupervisorJob())
    val dataBase by lazy {WordRoomDataBase.WordRoomDatabase.getDatabase(this, applicationScope)}
    val repository by lazy { WordRepository(dataBase.wordDao()) }
}