package com.example.livecicle

import androidx.annotation.WorkerThread
import kotlinx.coroutines.flow.Flow

class WordRepository (private val wordDAO: wordDAO) {
    val allWord = wordDAO.getAlphabetizedWords()

    @Suppress("RedundantSuspendModifier")
    @WorkerThread
    suspend fun insert(word: word.Word) {
        wordDAO.insert(word)
    }

}